| **Version** | **Date Modified (DD-MM-YYYY)** | **Change History**                                     |
|-------------|--------------------------------|--------------------------------------------------------|
| 3.0.0       | 24-08-2024                     | Updated the python runtime version to 3.11             |
| 3.0.0       | 11-12-2023                     | Added new **Parser** (Auth0AM)                         | 

